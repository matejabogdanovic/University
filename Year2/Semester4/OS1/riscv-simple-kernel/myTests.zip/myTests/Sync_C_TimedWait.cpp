//
// Created by os on 5/17/24.
//

#include "Sync_C_TimedWait.hpp"

namespace SyncCTimedWait{
    //CHANGE THIS HOW YOU WANT
    static const time_t timeout = 15; // as timeout time is increased, number of timeouts will decrease
    static const int busywait_duration = 10000000;

    static sem_t s;
    struct S {
        int arg;
        bool finished = false;
    };

    void func(void* arg){
        int argument = ((S *) arg)->arg;
        printString("\t\tFUNC_START_");printInt(argument);putc('\n');
        if(argument == 1){printString("\t\tsem_wait: ");printInt(argument);putc('\n');sem_wait(s);}
    if(argument == 2){
            printString("\t\tsem_timedwait: ");printInt(argument);putc('\n');
            int status = sem_timedwait(s, timeout);
            if(status == -2)
                printString("\t\tTIMEDOUT\n");
            else if(status == -1)
                printString("\t\tSEMDEAD\n");
            else if(status == 0)
                printString("\t\tsem_timedwait: passed\n");
        }

        for (int i = 0; i < 100; ++i) {
            for (int j = 0; j < busywait_duration; ++j) {

            }
            if (i % 10 == 0) {
                printString("\t\tdispatch: ");printInt(argument);putc('\n');
                thread_dispatch();
                printString("\t\t");
            }
            printInt(argument);
        }
        sem_signal(s);

        printString("\t\tFUNC_END_");printInt(argument);putc('\n');
        ((S*)arg)->finished = true;
    }

    void foo(void * arg){
        sem_t sem = (sem_t)arg;
        printString("\t\tFOO\n\t\t");

        for (int i = 0; i < 100; ++i) {
            for (int j = 0; j < busywait_duration; ++j) {

            }

            printString("_");
        }
        printString("\t\tsem_signal\n");
        sem_signal(sem);
        printString("\t\tFOO_END\n");
    }

    void Main(){
        printString("\tSync_C_TimedWait\n");
        S *jedan = new S();
        jedan->arg = 1;
        S *dva = new S();
        dva->arg = 2;


        sem_open(&s, 1);

        thread_t t1, t2;
        thread_create(&t1, func, jedan);
        thread_create(&t2, func, dva);



        while (!(jedan->finished && dva->finished))
            thread_dispatch();
        printString("\tBACK_TO_MAIN\n");


        sem_close(s);
        if(sem_close(s) < 0 )printString("\tCan't close semaphore again!\n");
        if(sem_signal(s) < 0 )printString("\tCan't signal closed semaphore!\n");
        delete jedan;
        delete dva;
        printString("\tSync_C_TimedWait\n");
    }
}

/*
Sync_C_TimedWait
        FUNC_START_1
sem_wait: 1
dispatch: 1
FUNC_START_2
        sem_timedwait: 2
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		dispatch: 1
1111111111		FUNC_END_1
        sem_timedwait: passed
        dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		dispatch: 2
2222222222		FUNC_END_2
        BACK_TO_MAIN
Can't close semaphore again!
Can't signal closed semaphore!
Sync_C_TimedWait*/
