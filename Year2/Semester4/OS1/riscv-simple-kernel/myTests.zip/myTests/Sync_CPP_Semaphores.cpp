//
// Created by os on 5/16/24.
//

#include "Sync_CPP_Semaphores.hpp"


namespace SyncCPPSemaphores {
    static Semaphore* s;
    int volatile n[2]{0, 0};
    struct S {
        int arg;
        bool finished = false;
    };

    class Func : public Thread {
        void func(void *arg);

        void *arg;
    public:
        Func(void *arg) : Thread() { this->arg = arg; }

        void run() override {
            func(arg);
        }
    };

    static void foo(void *arg) {
        int argument = ((S *) arg)->arg;

        printString("\t\tFUNC_START_");printInt(argument);putc('\n');
        printString("\t\tsem_wait: ");printInt(argument);putc('\n');
        s->wait();

        for (int i = 0; i < 100; ++i) {
            if (i % 25 == 0) { // dispatch on i = 0
                printString("\t\tdispatch: ");
                printInt(argument);
                putc('\n');
                Thread::dispatch();
                putc('\t');
                putc('\t');

            }

            printInt(argument);
        }
        printString("\t\tEND_FOR_LOOP\n\t\tArray is: ");

        n[argument - 1] = argument;
        for (int i: n)printInt(i);
        putc('\n');

        printString("\t\tsem_signal: ");printInt(argument);putc('\n');
        s->signal();

        printString("\t\tFUNC_END_");
        printInt(argument);
        putc('\n');
        ((S *) arg)->finished = true;
    }

    void Func::func(void *arg) {
        foo(arg);
    }


    void Main() {
        printString("\tSync_CPP_Semaphores\n");
        S *jedan = new S();
        jedan->arg = 1;
        S *dva = new S();
        dva->arg = 2;

        Thread *t1 = new Func(jedan);
        Thread *t2 = new Thread(foo, dva); // another way
        s = new Semaphore(1);


        t1->start();
        t2->start();

        while (!(jedan->finished && dva->finished))
            Thread::dispatch();

        printString("\tBACK_TO_MAIN\n");
        printString("\tArray is: ");
        for (int i: n)printInt(i);
        putc('\n');

        delete jedan;
        delete dva;
        delete s;
        delete t1;
        delete t2;
        printString("\tSync_CPP_Semaphores_END\n");


    }

}

/*
 	Sync_CPP_Semaphores
		FUNC_START_1
		sem_wait: 1
		dispatch: 1
		FUNC_START_2
		sem_wait: 2
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		END_FOR_LOOP
		Array is: 10
		sem_signal: 1
		FUNC_END_1
		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		END_FOR_LOOP
		Array is: 12
		sem_signal: 2
		FUNC_END_2
	BACK_TO_MAIN
	Array is: 12
	Sync_CPP_Semaphores_END
FINISHED-USER-MAIN
DEALLOCATED:-YES
 */