//
// Created by os on 5/16/24.
//
#include "Sync_C_Semaphores.hpp"

namespace SyncCSemaphores {


    int volatile n[2];
    struct S {
        int arg;
        bool finished = false;
    };
    static sem_t s;

    static void func(void *arg) {
        int argument = ((S *) arg)->arg;
        printString("\t\tFUNC_START_");printInt(argument);putc('\n');
        printString("\t\tsem_wait: ");printInt(argument);putc('\n');
        sem_wait(s);


        for (int i = 0; i < 100; ++i) {
            if (i % 25 == 0) { // dispatch on i = 0
                printString("\t\tdispatch: ");printInt(argument);putc('\n');
                thread_dispatch();
                putc('\t');putc('\t');

            }

            printInt(argument);
        }
        printString("\t\tEND_FOR_LOOP\n\t\tArray is: ");

        n[argument - 1] = argument;
        for (int i: n)printInt(i);
        putc('\n');

        printString("\t\tsem_signal: ");printInt(argument);putc('\n');
        sem_signal(s);
        printString("\t\tFUNC_END_");printInt(argument);putc('\n');
        ((S *) arg)->finished = true;

    }

    void Main() {

        printString("\tSync_C_Semaphores\n");
        S *jedan = new S();
        jedan->arg = 1;
        S *dva = new S();
        dva->arg = 2;

        sem_open(&s, 1);

        thread_t t1, t2;
        thread_create(&t1, func, jedan);
        thread_create(&t2, func, dva);


        while (!(jedan->finished && dva->finished))
            thread_dispatch();

        printString("\tBACK_TO_MAIN\n");
        printString("\tArray is: ");
        for (int i: n)printInt(i);
        putc('\n');

        delete jedan;
        delete dva;
        printString("\tsem_close\n");
        sem_close(s);

        printString("\tSync_C_Semaphores_END\n");
    }

}

/*
	Sync_C_Semaphores
		FUNC_START_1
		sem_wait: 1
		dispatch: 1
		FUNC_START_2
		sem_wait: 2
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		dispatch: 1
		1111111111111111111111111		END_FOR_LOOP
		Array is: 10
		sem_signal: 1
		FUNC_END_1
		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		dispatch: 2
		2222222222222222222222222		END_FOR_LOOP
		Array is: 12
		sem_signal: 2
		FUNC_END_2
	BACK_TO_MAIN
	Array is: 12
	sem_close
	Sync_C_Semaphores_END
FINISHED-USER-MAIN
DEALLOCATED:-YES
*/