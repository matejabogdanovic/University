//
// Created by os on 5/16/24.
//

#ifndef PROJECT_BASE_SYNC_CPP_SEMAPHORES_HPP
#define PROJECT_BASE_SYNC_CPP_SEMAPHORES_HPP
#include "../h/syscall_cpp.hpp"
#include "printing.hpp"
namespace SyncCPPSemaphores {
    void Main();
}
#endif //PROJECT_BASE_SYNC_CPP_SEMAPHORES_HPP
