//
// Created by os on 5/18/24.
//

#ifndef PROJECT_BASE_SYNC_CPP_PERIODICTHREAD_HPP
#define PROJECT_BASE_SYNC_CPP_PERIODICTHREAD_HPP
#include "../h/syscall_cpp.hpp"
#include "printing.hpp"
namespace SyncCPPPeriodicThread{
    void Main();
}
#endif //PROJECT_BASE_SYNC_CPP_PERIODICTHREAD_HPP
