//
// Created by os on 5/16/24.
//

#include "Async_CPP_Semaphores.hpp"
namespace AsyncCPPSemaphores {
    static Semaphore* sems[2];
    int volatile n[2]{0, 0};
    struct S {
        int arg;
        bool finished = false;
    };

    class Func : public Thread {
        void func(void *arg);

        void *arg;
    public:
        Func(void *arg) : Thread() { this->arg = arg; }

        void run() override {
            func(arg);
        }
    };

    static void foo(void *arg) {
        int argument = ((S *) arg)->arg;

        printString("\t\tFUNC_START_");printInt(argument);putc('\n');

        for (int i = 0; i < 100; ++i) {
            for (int j = 0; j < 10000000; ++j) { /* busy wait */ }

            printInt(argument);
        }
        printString("\t\tEND_FOR_LOOP\n\t\tArray is: ");

        n[argument - 1] = argument;
        for (int i: n)printInt(i);
        putc('\n');

        printString("\t\tsem_signal: ");printInt(argument);putc('\n');
        sems[argument-1]->signal();

        printString("\t\tFUNC_END_");
        printInt(argument);
        putc('\n');
        ((S *) arg)->finished = true;
    }

    void Func::func(void *arg) {
        foo(arg);
    }


    void Main() {
        printString("\tAsync_CPP_Semaphores\n");
        S *jedan = new S();
        jedan->arg = 1;
        S *dva = new S();
        dva->arg = 2;

        Thread *t1 = new Func(jedan);
        Thread *t2 = new Thread(foo, dva); // another way
        sems[0] = new Semaphore(0);
        sems[1] = new Semaphore(0);

        t1->start();
        t2->start();

//        while (!(jedan->finished && dva->finished))
//            Thread::dispatch();

        for(Semaphore* s: sems){
            s->wait();
        }


        printString("\tBACK_TO_MAIN\n");
        printString("\tArray is: ");
        for (int i: n)printInt(i);
        putc('\n');

        for(Semaphore* s: sems){
            delete s;
        }


        delete jedan;
        delete dva;
        delete t1;
        delete t2;
        printString("\tAsync_CPP_Semaphores_END\n");


    }

}
// Something similar to this. No dispatch used. Uncomment _thread::dispatch() in timer handler.
/*
    Async_CPP_Semaphores
		FUNC_START_1
1111111111		FUNC_START_2
222222222222222221111111111111111112222222222222222211111111111111112222222222222222222111111111111111111122222222222222222211111111111111111122222222222222222211111111111111111122222222222		END_FOR_LOOP
		Array is: 02
		sem_signal: 2
		FUNC_END_2
1		END_FOR_LOOP
		Array is: 12
		sem_signal: 1
		FUNC_END_1
	BACK_TO_MAIN
	Array is: 12
	Async_CPP_Semaphores_END
FINISHED-USER-MAIN
DEALLOCATED:-YES
 */