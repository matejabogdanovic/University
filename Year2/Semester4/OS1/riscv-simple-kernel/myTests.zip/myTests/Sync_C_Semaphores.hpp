//
// Created by os on 5/16/24.
//

#ifndef PROJECT_BASE_SYNC_C_SEMAPHORES_HPP
#define PROJECT_BASE_SYNC_C_SEMAPHORES_HPP
#include "../h/syscall_c.hpp"
#include "printing.hpp"
namespace SyncCSemaphores {

    void Main();

}
#endif //PROJECT_BASE_SYNC_C_SEMAPHORES_HPP
