//
// Created by os on 5/17/24.
//

#ifndef PROJECT_BASE_SYNC_C_TIMEDWAIT_HPP
#define PROJECT_BASE_SYNC_C_TIMEDWAIT_HPP
#include "../h/syscall_c.hpp"
#include "printing.hpp"
namespace SyncCTimedWait{
    void Main();
}
#endif //PROJECT_BASE_SYNC_C_TIMEDWAIT_HPP
