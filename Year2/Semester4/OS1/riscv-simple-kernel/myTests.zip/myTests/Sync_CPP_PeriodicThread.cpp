//
// Created by os on 5/18/24.
//

#include "Sync_CPP_PeriodicThread.hpp"
namespace SyncCPPPeriodicThread {

    static const time_t period = 1;
    static int i = 0;
    Semaphore* sem;
    class PT : public PeriodicThread{
    public:
        PT(time_t _period) : PeriodicThread(_period){}
        virtual void periodicActivation () {
            printString("\t\tperiodicActivation\n");

            if(++i == 2) {
                sem->signal();
                thread_dispatch(); // if commented, thread will first finish, fall asleep and then it will be terminated
            }

            printString("\t\tperiodicActivation_FINISHED\n");
        }
    };


    void func(void * ){
        for (int j = 0; j < 1000; ++j) {

            thread_dispatch();
        }
    }

    void Main() {
        printString("\tSync_CPP_PeriodicThread\n");
        PT* t = new PT(period);
        sem = new Semaphore(0);
        Thread* foo = new Thread(func, nullptr);

        foo->start();

        t->start();
        sem->wait();
        t->terminate();


        delete foo;
        delete sem;
        delete t;
        printString("\tSync_CPP_PeriodicThread_END\n");
    }

}

/*
    Sync_CPP_PeriodicThread
		periodicActivation
		periodicActivation_FINISHED
		periodicActivation
	Sync_CPP_PeriodicThread_END
 */

