//
// Created by os on 5/16/24.
//

#include "Sync_C_Threads.hpp"

namespace SyncCThreads {
    int volatile n[2]{0,0};

    struct S {
        int arg;
        bool finished = false;
    };

    static void func(void *arg) {
        int argument = ((S *) arg)->arg;
        printString("\t\tFUNC_START_");printInt(argument);putc('\n');
        for (int i = 0; i < 100; ++i) {
            if (i % 25 == 0) { // dispatch on i = 0
                printString("\t\tdispatch: ");printInt(argument);putc('\n');
//                __asm__ volatile("li a0, 0x69");
//                uint64 volatile a0;
//                __asm__ volatile ("mv %[a0], a0" : [a0] "=r"(a0));
//                printInt(a0, 16);

                thread_dispatch();

//                __asm__ volatile ("mv %[a0], a0" : [a0] "=r"(a0));
//                printInt(a0, 16);
                putc('\t');putc('\t');

            }

            printInt(argument);
        }
        printString("\t\tEND_FOR_LOOP\n\t\tArray is: ");

        n[argument - 1] = argument;
        for (int i: n)printInt(i);
        putc('\n');

        printString("\t\tFUNC_END_");printInt(argument);putc('\n');
        ((S *) arg)->finished = true;
    }

    void Main() {

        printString("\tSync_C_Threads\n");
        S *jedan = new S();
        jedan->arg = 1;
        S *dva = new S();
        dva->arg = 2;


        thread_t t1, t2;
        thread_create(&t1, func, jedan);
        thread_create(&t2, func, dva);


        while (!(jedan->finished && dva->finished))
            thread_dispatch();
        printString("\tBACK_TO_MAIN\n");
        printString("\tArray is: ");
        for (int i: n)printInt(i);
        putc('\n');

        delete jedan;
        delete dva;
        printString("\tSync_C_Threads_END\n");
    }
}

/*
	Sync_C_Threads
		FUNC_START_1
		dispatch: 1
		FUNC_START_2
		dispatch: 2
		1111111111111111111111111		dispatch: 1
		2222222222222222222222222		dispatch: 2
		1111111111111111111111111		dispatch: 1
		2222222222222222222222222		dispatch: 2
		1111111111111111111111111		dispatch: 1
		2222222222222222222222222		dispatch: 2
		1111111111111111111111111		END_FOR_LOOP
		Array is: 10
		FUNC_END_1
		2222222222222222222222222		END_FOR_LOOP
		Array is: 12
		FUNC_END_2
	BACK_TO_MAIN
	Array is: 12
	Sync_C_Threads_END
FINISHED-USER-MAIN
DEALLOCATED:-YES
*/
