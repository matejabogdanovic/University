#include "../h/syscall_c.hpp"
#include "../h/syscall_cpp.hpp"
#include "printing.hpp"


#define pick 6

#if pick == 0
    #include "Sync_C_Threads.hpp"
#endif

#if pick == 1
    #include "Sync_C_Semaphores.hpp"
#endif

#if pick == 2
    #include "Sync_CPP_Threads.hpp"
#endif

#if pick == 3
    #include "Sync_CPP_Semaphores.hpp"
#endif

#if pick == 4
    #include "Async_CPP_Semaphores.hpp"
#endif

#if pick == 5
    #include "Sync_C_TimedWait.hpp"
#endif

#if pick == 6
    #include "Sync_CPP_PeriodicThread.hpp"
#endif
int _userMain(){

#if pick == 0
    SyncCThreads::Main();
#endif
#if pick == 1
    SyncCSemaphores::Main();
#endif
#if pick == 2
    SyncCPPThreads::Main();
#endif
#if pick == 3
    SyncCPPSemaphores::Main();
#endif
#if pick == 4
    AsyncCPPSemaphores::Main();
#endif
#if pick == 5
    SyncCTimedWait::Main();
#endif
#if pick == 6
    SyncCPPPeriodicThread::Main();
#endif
    return 0;
}

